@section('css-script')
<link href="{{ asset('plugins/sweetalert2') }}/dist/sweetalert2.min.css" rel="stylesheet">
@stop

@section('js-script')
<script src="{{ asset('plugins/sweetalert2') }}/dist/sweetalert2.min.js"></script>
@stop